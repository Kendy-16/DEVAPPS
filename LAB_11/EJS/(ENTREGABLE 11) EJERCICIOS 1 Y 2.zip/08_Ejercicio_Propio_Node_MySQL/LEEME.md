# 08_Ejercicio_Propio_Node_MySQL

Consulta Node+MySQL con JOIN y GROUP BY; importar db/laboratorio10.sql.

## Ejecución

```bash
npm install
npm start
```

Archivo principal: `consulta.js`.
Consulta los registros directamente en la terminal.

## Requisito adicional de MySQL

Antes de ejecutar, importa el archivo SQL incluido en `db/` mediante phpMyAdmin o MySQL Workbench.
Los valores predeterminados corresponden a WampServer: `127.0.0.1:3006`, usuario `root` sin contraseña.
Puedes sobrescribir `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` y `DB_NAME` por variables de entorno.

> Proyecto didáctico realizado para la sesión N.° 10. Los datos de demostración son ficticios.
