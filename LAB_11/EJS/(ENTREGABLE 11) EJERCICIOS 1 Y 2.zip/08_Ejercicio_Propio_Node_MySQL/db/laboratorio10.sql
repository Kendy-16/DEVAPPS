CREATE DATABASE IF NOT EXISTS laboratorio10 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE laboratorio10;
CREATE TABLE IF NOT EXISTS categorias (
 id INT PRIMARY KEY, nombre VARCHAR(60) NOT NULL
);
CREATE TABLE IF NOT EXISTS libros (
 id INT PRIMARY KEY, titulo VARCHAR(120) NOT NULL, autor VARCHAR(100) NOT NULL,
 categoria_id INT NOT NULL, stock INT NOT NULL DEFAULT 0,
 CONSTRAINT fk_libros_categoria FOREIGN KEY(categoria_id) REFERENCES categorias(id)
);
INSERT INTO categorias(id,nombre) VALUES(1,'Tecnología'),(2,'Novela'),(3,'Ciencia')
ON DUPLICATE KEY UPDATE nombre=VALUES(nombre);
INSERT INTO libros(id,titulo,autor,categoria_id,stock) VALUES
(1,'Algoritmos al alcance','Lucía Torres',1,5),
(2,'Arquitectura para todos','Marco Núñez',1,7),
(3,'El puente de papel','Elena Mena',2,3),
(4,'Ciudad de invierno','M. Salas',2,4),
(5,'La materia en movimiento','A. Rojas',3,6)
ON DUPLICATE KEY UPDATE titulo=VALUES(titulo),autor=VALUES(autor),categoria_id=VALUES(categoria_id),stock=VALUES(stock);
