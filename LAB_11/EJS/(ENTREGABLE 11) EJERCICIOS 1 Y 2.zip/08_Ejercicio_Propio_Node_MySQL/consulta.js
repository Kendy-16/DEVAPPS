// Ejercicio propio Node 02: SELECT con JOIN y GROUP BY en MySQL.
const mysql=require('mysql2/promise');
const config={host:process.env.DB_HOST||'127.0.0.1',port:Number(process.env.DB_PORT||3306),user:process.env.DB_USER||'root',password:process.env.DB_PASSWORD||'',database:process.env.DB_NAME||'laboratorio10',connectTimeout:8000};
async function main(){let db;
 try{db=await mysql.createConnection(config);
 console.log('=== REPORTE DE LIBROS POR CATEGORÍA ===');
 const [resumen]=await db.execute(`SELECT c.nombre AS categoria, COUNT(l.id) AS libros, COALESCE(SUM(l.stock),0) AS ejemplares FROM categorias c LEFT JOIN libros l ON l.categoria_id=c.id GROUP BY c.id,c.nombre ORDER BY c.nombre`);
 console.table(resumen);
 const [libros]=await db.execute(`SELECT l.titulo, l.autor, c.nombre AS categoria, l.stock FROM libros l INNER JOIN categorias c ON l.categoria_id=c.id ORDER BY l.titulo`);
 console.log('=== DETALLE DEL INVENTARIO ===');console.table(libros);
 }catch(err){console.error('Error:',err.message);console.error('Importa db/laboratorio10.sql y verifica WampServer/MySQL puerto 3006.');process.exitCode=1;}
 finally{if(db)await db.end()}}
main();
