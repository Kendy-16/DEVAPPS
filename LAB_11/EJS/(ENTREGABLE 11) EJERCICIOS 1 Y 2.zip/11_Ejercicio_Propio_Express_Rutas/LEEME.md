# 11_Ejercicio_Propio_Express_Rutas

Express.Router: agenda e inscripciones en memoria.

## Ejecución

```bash
npm install
npm start
```

Archivo principal: `servidor.js`.
Visita **http://localhost:4205**.

> Proyecto didáctico realizado para la sesión N.° 10. Los datos de demostración son ficticios.
