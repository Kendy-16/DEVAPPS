const express=require('express');const path=require('node:path');
const talleres=require('./rutas/talleres');
const app=express();const PORT=Number(process.env.PORT||4205);
app.use(express.json({limit:'5kb'}));app.use(express.static(path.join(__dirname,'public')));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.use('/api/talleres',talleres);
app.use((req,res)=>res.status(404).json({error:'Ruta no encontrada'}));
app.listen(PORT,()=>console.log(`TRAVESÍA rutas: http://localhost:${PORT}`));
