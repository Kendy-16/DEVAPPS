let talleres=[];let filtro='Todas';
const $=id=>document.getElementById(id);
async function cargar(){try{const r=await fetch('/api/talleres');talleres=await r.json();pintar()}catch(e){$('talleres').textContent=e.message}}
function pintar(){const lista=talleres.filter(x=>filtro==='Todas'||x.area===filtro);const destino=$('talleres');destino.replaceChildren();$('cantidad').textContent=lista.length+' sesiones';
 for(const t of lista){const c=document.createElement('article');c.className='card';
 const over=document.createElement('div');over.className='overline';over.textContent=`${t.area} · ${t.duracion}`;
 const h=document.createElement('h2');h.textContent=t.titulo;const p=document.createElement('p');p.textContent=`${t.cupos-t.inscritos} cupos disponibles de ${t.cupos}`;
 const a=document.createElement('a');a.className='link-line';a.href='/api/talleres/'+t.id;a.textContent='Abrir detalle JSON ↗';
 c.append(over,h,p,a);destino.append(c);
 }
 const select=$('taller');const old=select.value;select.replaceChildren();for(const t of talleres){const o=document.createElement('option');o.value=t.id;o.textContent=t.titulo+` (${t.cupos-t.inscritos} cupos)`;o.disabled=t.inscritos>=t.cupos;select.append(o)}if(talleres.some(t=>String(t.id)===old))select.value=old;
}
document.querySelectorAll('[data-area]').forEach(btn=>btn.addEventListener('click',()=>{filtro=btn.dataset.area;document.querySelectorAll('[data-area]').forEach(b=>b.classList.toggle('is-active',b===btn));pintar()}));
$('form').addEventListener('submit',async e=>{e.preventDefault();const nombre=$('nombre').value.trim(),id=$('taller').value;try{
 const r=await fetch(`/api/talleres/${encodeURIComponent(id)}/inscripciones`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({nombre})});const v=await r.json();if(!r.ok)throw Error(v.error);$('respuesta').textContent=`${v.mensaje} · Quedan ${v.disponibles} cupos.`;$('nombre').value='';cargar();
 }catch(error){$('respuesta').textContent=error.message}});
cargar();
