// Ejercicio propio de express.Router(): rutas de una agenda de talleres.
const express=require('express');const router=express.Router();
const talleres=[
 {id:1,titulo:'Introducción a Node',area:'Backend',duracion:'80 min',cupos:12,inscritos:0,simbolo:'N'},
 {id:2,titulo:'Diseño de interfaces',area:'Frontend',duracion:'70 min',cupos:9,inscritos:0,simbolo:'D'},
 {id:3,titulo:'Rutas con Express',area:'Backend',duracion:'95 min',cupos:15,inscritos:0,simbolo:'R'},
 {id:4,titulo:'Datos y MySQL',area:'Datos',duracion:'75 min',cupos:10,inscritos:0,simbolo:'S'}
];
router.get('/',(req,res)=>res.json(talleres));
router.get('/:id',(req,res)=>{const t=talleres.find(x=>x.id===Number(req.params.id));if(!t)return res.status(404).json({error:'Taller no encontrado'});res.json(t)});
router.post('/:id/inscripciones',(req,res)=>{
 const t=talleres.find(x=>x.id===Number(req.params.id));if(!t)return res.status(404).json({error:'Taller no encontrado'});
 const nombre=String(req.body?.nombre||'').trim();if(nombre.length<2||nombre.length>60)return res.status(400).json({error:'Escribe un nombre de 2 a 60 caracteres.'});
 if(t.inscritos>=t.cupos)return res.status(409).json({error:'No quedan cupos.'});
 t.inscritos++;res.status(201).json({mensaje:`Inscripción simulada de ${nombre}`,taller:t.titulo,disponibles:t.cupos-t.inscritos});
});
module.exports=router;
