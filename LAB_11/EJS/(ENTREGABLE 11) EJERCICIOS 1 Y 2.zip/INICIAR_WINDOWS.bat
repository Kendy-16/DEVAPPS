@echo off
setlocal EnableExtensions
chcp 65001 >nul
cd /d "%~dp0"
:MENU
cls
echo ======================================================
echo     UCSM - LABORATORIO N. 11 - NODE.JS Y EXPRESS
echo ======================================================
echo  EJERCICIOS PROPIOS
 echo  7. Node HTTP - RADAR
 echo  8. Node + MySQL - Biblioteca
 echo  9. Node + HTML - PIZARRA
 echo 10. Express basico - INCISO
 echo 11. Express rutas - TRAVESIA
 echo 12. Express middleware - CERROJO
 echo.
echo  0. Salir
 echo.
set /p opt=Elige un proyecto (7-12): 
set "dir="
if "%opt%"=="7" set "dir=07_Ejercicio_Propio_Node_HTTP"
if "%opt%"=="8" set "dir=08_Ejercicio_Propio_Node_MySQL"
if "%opt%"=="9" set "dir=09_Ejercicio_Propio_Node_HTML"
if "%opt%"=="10" set "dir=10_Ejercicio_Propio_Express_Basico"
if "%opt%"=="11" set "dir=11_Ejercicio_Propio_Express_Rutas"
if "%opt%"=="12" set "dir=12_Ejercicio_Propio_Express_Middleware"
if "%opt%"=="0" exit /b 0
if not defined dir (
  echo Opcion invalida.
  pause
  goto MENU
)
where node >nul 2>nul
if errorlevel 1 (
 echo ERROR: Instala Node.js desde https://nodejs.org/
 pause
 goto MENU
)
pushd "%dir%"
if not exist node_modules (
  echo Instalando dependencias si son necesarias...
  call npm install --no-audit --no-fund
  if errorlevel 1 (
    echo ERROR al instalar dependencias.
    popd
    pause
    goto MENU
  )
)
echo.
echo Para detener la aplicacion: CTRL + C
call npm start
popd
pause
goto MENU
