// Ejercicio propio Express básico: API de notas con validación y memoria volátil.
const express=require('express');const path=require('node:path');
const app=express();const PORT=Number(process.env.PORT||4204);
app.use(express.json({limit:'6kb'}));
app.use(express.static(path.join(__dirname,'public')));
let counter=2;let notas=[{id:1,autor:'Equipo',texto:'Las rutas responden a métodos HTTP.',area:'Backend'},{id:2,autor:'Laboratorio',texto:'Los datos se reinician al cerrar Node.',area:'Conceptos'}];
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.get('/api/notas',(req,res)=>res.json(notas));
app.post('/api/notas',(req,res)=>{
 const autor=String(req.body?.autor||'').trim(),texto=String(req.body?.texto||'').trim(),area=String(req.body?.area||'').trim();
 if(!autor||autor.length>35||!texto||texto.length>240||!['Backend','Conceptos','Ideas'].includes(area))return res.status(400).json({error:'Completa los campos respetando las longitudes y el área.'});
 const nota={id:++counter,autor,texto,area};notas.unshift(nota);res.status(201).json(nota);
});
app.delete('/api/notas/:id',(req,res)=>{
 const id=Number(req.params.id);const n=notas.length;notas=notas.filter(x=>x.id!==id);
 if(n===notas.length)return res.status(404).json({error:'Nota no encontrada'});
 res.status(204).end();
});
app.use((req,res)=>res.status(404).json({error:'Ruta inexistente'}));
app.listen(PORT,()=>console.log(`INCISO Express: http://localhost:${PORT}`));
