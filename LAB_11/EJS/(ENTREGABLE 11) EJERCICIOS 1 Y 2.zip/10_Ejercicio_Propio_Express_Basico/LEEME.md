# 10_Ejercicio_Propio_Express_Basico

Express: API de notas GET, POST y DELETE.

## Ejecución

```bash
npm install
npm start
```

Archivo principal: `app.js`.
Visita **http://localhost:4204**.

> Proyecto didáctico realizado para la sesión N.° 10. Los datos de demostración son ficticios.
