async function cargar(){const el=document.getElementById('lista');try{const r=await fetch('/api/notas');const data=await r.json();el.replaceChildren();document.getElementById('counter').textContent=data.length;
 if(!data.length){el.innerHTML='<div class="empty wide">No hay notas. Publica una.</div>'}
 for(const n of data){const card=document.createElement('article');card.className='card';const over=document.createElement('div');over.className='overline';over.textContent=n.area;
 const h=document.createElement('h2');h.textContent=n.autor;const p=document.createElement('p');p.textContent=n.texto;
 const del=document.createElement('button');del.className='filter';del.textContent='Eliminar';del.addEventListener('click',async()=>{const r=await fetch('/api/notas/'+n.id,{method:'DELETE'});if(r.ok)cargar()});
 card.append(over,h,p,del);el.append(card)}
 }catch(e){el.textContent=e.message}}
document.getElementById('form').addEventListener('submit',async e=>{e.preventDefault();const autor=document.getElementById('autor').value.trim(),texto=document.getElementById('texto').value.trim(),area=document.getElementById('area').value;
 const estado=document.getElementById('estado');try{const r=await fetch('/api/notas',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({autor,texto,area})});const v=await r.json();if(!r.ok)throw Error(v.error);estado.textContent='Nota creada correctamente · respuesta 201';document.getElementById('texto').value='';cargar()}catch(err){estado.textContent=err.message}});
cargar();
