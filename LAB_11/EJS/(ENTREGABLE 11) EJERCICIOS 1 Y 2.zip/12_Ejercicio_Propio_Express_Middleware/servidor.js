// Ejercicio propio de middleware: logger + protección de demostración.
const express=require('express');const path=require('node:path');
const app=express();const PORT=Number(process.env.PORT||4206);
const TOKEN=process.env.DEMO_TOKEN||'LAB-10-DEMO';
let counter=0;const auditoria=[];
function registro(req,res,next){
 const id=++counter;const inicio=Date.now();
 res.on('finish',()=>{
  auditoria.unshift({id,metodo:req.method,ruta:req.path,estado:res.statusCode,ms:Date.now()-inicio});
  if(auditoria.length>25)auditoria.pop();
  console.log(`[AUDITORÍA] #${id} ${req.method} ${req.path} → ${res.statusCode}`);
 });next();
}
function proteger(req,res,next){
 if(req.get('x-lab-token')!==TOKEN)return res.status(401).json({error:'Acceso denegado por el middleware',codigo:401});
 next();
}
app.use(registro);
app.use(express.static(path.join(__dirname,'public')));
app.get('/',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.get('/api/publico',(req,res)=>res.json({mensaje:'Zona pública accesible sin token'}));
app.get('/api/privado',proteger,(req,res)=>res.json({mensaje:'Acceso permitido: el middleware ejecutó next()'}));
app.get('/api/auditoria',(req,res)=>res.json(auditoria));
app.listen(PORT,()=>console.log(`CERROJO middleware: http://localhost:${PORT}`));
