const $=id=>document.getElementById(id);
async function auditoria(){try{const items=await fetch('/api/auditoria').then(x=>x.json());const d=$('audit');d.replaceChildren();for(const x of items.slice(0,12)){const row=document.createElement('div');row.className='log-line';row.textContent=`#${x.id}  ${x.metodo} ${x.ruta} → ${x.estado} (${x.ms} ms)`;d.append(row)}}catch(e){$('audit').textContent=e.message}}
async function probar(tipo){const headers=tipo==='permitido'?{'X-Lab-Token':'LAB-10-DEMO'}:{};const ruta=tipo==='publico'?'/api/publico':'/api/privado';
 try{const r=await fetch(ruta,{headers});const data=await r.json();$('status').textContent=String(r.status);$('resultado').textContent=data.mensaje||data.error||'Sin mensaje';await auditoria();}catch(e){$('resultado').textContent=e.message}}
$('publico').onclick=()=>probar('publico');$('denegado').onclick=()=>probar('denegado');$('permitido').onclick=()=>probar('permitido');auditoria();
