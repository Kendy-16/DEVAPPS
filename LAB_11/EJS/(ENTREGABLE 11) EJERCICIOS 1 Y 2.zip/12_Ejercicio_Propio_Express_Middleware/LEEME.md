# 12_Ejercicio_Propio_Express_Middleware

Middleware de auditoría y acceso con token didáctico.

## Ejecución

```bash
npm install
npm start
```

Archivo principal: `servidor.js`.
Visita **http://localhost:4206**.

> Proyecto didáctico realizado para la sesión N.° 10. Los datos de demostración son ficticios.
